

-- Q.7 Customer Lifetime Value Modeling: How can you leverage customer data (tenure, purchase history, engagement) to predict the lifetime value of different customer segments? This could inform targeted marketing and loyalty program strategies. Can you observe any common characteristics or purchase patterns among customers who have stopped purchasing?

-- we can see that some countries have multiple customer_id, so they are more interested in buying from us
select 
Customer_Id,
billing_country as Country,
timestampdiff(month, min(invoice_date), max(invoice_date)) as Tenure_in_months,
Count(distinct invoice_id) as Number_of_Purchases,
sum(total) as Total_Spent
from invoice
group by customer_id,billing_country
order by Country
