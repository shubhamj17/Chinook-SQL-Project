

-- Q4. Product Affinity Analysis: Which music genres, artists, or albums are frequently purchased together by customers? How can this information guide product recommendations and cross-selling initiatives?

select
    g.name as Purchased_Genre,
    al.title as Recommended_Album,
    ar.name as Recommended_Artist,
    count(distinct il.invoice_id) as Number_of_Copurchases
from invoice_line il
join track t on il.track_id = t.track_id
join genre g on t.genre_id = g.genre_id
join album al on t.album_id = al.album_id
join artist ar on al.artist_id = ar.artist_id
where exists (
    select 1
    from invoice_line il_inner
    join track t_inner on il_inner.track_id = t_inner.track_id
    where il_inner.invoice_id = il.invoice_id
      and t_inner.genre_id != t.genre_id
)
group by g.name, al.title, ar.name
order by g.name, Number_of_Copurchases desc;