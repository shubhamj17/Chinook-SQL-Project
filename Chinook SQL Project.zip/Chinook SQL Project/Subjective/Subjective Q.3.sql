

-- Q.3 Customer Purchasing Behavior Analysis: How do the purchasing habits (frequency, basket size, spending amount) of long-term customers differ from those of new customers? What insights can these patterns provide about customer loyalty and retention strategies?

with Customer_details as (
select Customer_id, 
timestampdiff(month, min(invoice_date), max(invoice_date)) as Month_Diff,
sum(total) as Total
from invoice
group by customer_id
)

select 
count(case when Month_Diff <=12 then 1 end) as One_Year,
count(case when Month_Diff between 13 and 24 then 1 end) as Two_Year,
count(case when Month_Diff between 25 and 36 then 1 end) as Three_Year,
count(case when Month_Diff between 37 and 48 then 1 end) as Four_Year
from Customer_details