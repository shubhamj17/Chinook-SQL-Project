

-- Q.6 Customer Risk Profiling: Based on customer profiles (age, gender, location, purchase history), which customer segments are more likely to churn or pose a higher risk of reduced spending? What factors contribute to this risk?

select billing_country as Country,
count(distinct customer_id) as No_of_Customers,
sum(total) as Total_Spent,
timestampdiff(month, min(invoice_date), max(invoice_date)) as Month_Diff
from invoice
group by billing_country
