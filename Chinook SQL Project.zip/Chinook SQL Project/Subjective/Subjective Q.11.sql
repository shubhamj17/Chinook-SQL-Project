

-- Q.11 Chinook is interested in understanding the purchasing behavior of customers based on their geographical location. They want to know the average total amount spent by customers from each country, along with the number of customers and the average number of tracks purchased per customer. Write an SQL query to provide this information.


with customer_purchases as (
select
c.country,
c.customer_id,
sum(i.total) as total_spent,
count(distinct il.track_id) as tracks_purchased
from customer c
left join invoice i on c.customer_id = i.customer_id
left join invoice_line il on i.invoice_id = il.invoice_id
group by c.country, c.customer_id
)
select
Country,
count(distinct customer_id) as No_of_Customers,
round(avg(total_spent),2) as Avg_Spent,
round(avg(tracks_purchased),2) as Avg_Tracks_Purchased
from customer_purchases
group by country
order by country