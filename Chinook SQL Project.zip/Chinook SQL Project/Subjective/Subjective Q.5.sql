

-- Q.5 Regional Market Analysis: Do customer purchasing behaviors and churn rates vary across different geographic regions or store locations? How might these correlate with local demographic or economic factors?

select 
billing_country as Country,
count(distinct customer_id) as No_of_customer,
round(coalesce(coalesce(count(distinct customer_id) - lag(count(distinct customer_id)) over (order by billing_country),0) / count(distinct customer_id) *100,0),2) as Percent_ChurnRate
from invoice
group by billing_country
order by Percent_ChurnRate