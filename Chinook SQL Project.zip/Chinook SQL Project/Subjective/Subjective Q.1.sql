

-- Q.1 Recommend the three albums from the new record label that should be prioritised for advertising and promotion in the USA based on genre sales analysis.

-- order the result in ascending order to get least sold albums and promote them

SELECT am.title AS Album_Name,
       g.name AS Genre,
       SUM(i.total) AS Total_Sales
FROM track t
JOIN invoice_line il ON t.track_id = il.track_id
JOIN invoice i ON i.invoice_id = il.invoice_id
JOIN genre g ON t.genre_id = g.genre_id
JOIN album am ON t.album_id = am.album_id
WHERE i.billing_country = "USA"
GROUP BY am.title, g.name
ORDER BY Total_Sales 
limit 3