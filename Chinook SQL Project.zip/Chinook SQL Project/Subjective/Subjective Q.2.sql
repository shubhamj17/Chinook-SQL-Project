

-- Q.2 Determine the top-selling genres in countries other than the USA and identify any commonalities or differences.

-- top 5 selling genres in other than USA are    	Rock,Metal,Alternative & Punk,Latin,Jazz
-- least 5 selling genres in other than USA are		Hip Hop/Rap,Heavy Metal,Soundtrack,TV Shows,Drama				
-- top 5 selling genres in USA are					Rock,Alternative & Punk,Metal,R&B/Soul,Blues
-- least 5 selling genres in USA are				Electronica/Dance,Heavy Metal,Classical,Soundtrack,TV Shows

select 
		g.name as Genre_name,
        sum(i.total) as Total_Sales
FROM track t
JOIN invoice_line il ON t.track_id = il.track_id
JOIN invoice i ON i.invoice_id = il.invoice_id
JOIN genre g ON t.genre_id = g.genre_id
where i.billing_country <> "USA"
group by g.name
order by Total_Sales desc