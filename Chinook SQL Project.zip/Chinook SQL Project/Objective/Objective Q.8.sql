

-- Q.8 What is the customer churn rate?

select 
extract(year from invoice_date) as Year,
count(distinct customer_id) as No_of_Customers,
coalesce(count(distinct customer_id) - lag(count(distinct customer_id)) over (order by extract(year from invoice_date)),0) as YoY_difference,
round(coalesce(coalesce(count(distinct customer_id) - lag(count(distinct customer_id)) over (order by extract(year from invoice_date)),0) / count(distinct customer_id) *100,0),2) as Percent_diff
from invoice
group by extract(year from invoice_date)
order by Year
