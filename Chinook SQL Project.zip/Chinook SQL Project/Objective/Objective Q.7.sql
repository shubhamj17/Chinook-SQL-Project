
-- Q.7 Are there any patterns or trends in customer purchasing behavior (e.g., frequency of purchases, preferred payment methods, average order value)?

select 
extract(month from invoice_date) as Month,
count(distinct invoice_id) as No_of_Purchases,
round(avg(total),2) as Avg_Order_Value
from invoice
group by month
order by Month