

-- Q.9 Calculate the percentage of total sales contributed by each genre in the USA and identify the best-selling genres and artists.

with GenreRank as (
select 
ar.name as Artist_Name,
g.name as Genre,
sum(i.total) as Total_Sales,
round(((sum(i.total))/ (select sum(total) from invoice)) *100,2) as Percentage_of_Total_Sales,
rank() over(partition by g.name order by sum(i.total) desc) as rnk
from track t
join invoice_line il on t.track_id=il.track_id
join invoice i on i.invoice_id=il.invoice_id
join genre g on t.genre_id=g.genre_id
join album am on t.album_id=am.album_id
join artist ar on am.artist_id=ar.artist_id
where i.billing_country = "USA"
group by ar.name,g.name
)

select Artist_Name,Genre,Total_Sales,Percentage_of_Total_Sales from GenreRank
where rnk = 1 
order by Percentage_of_Total_Sales desc