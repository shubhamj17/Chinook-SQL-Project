

-- Q.12 Identify customers who have not made a purchase in the last 3 months

select c.customer_id, c.first_name, c.last_name
from customer c
where not exists (
    select 1
    from invoice i
    where i.customer_id = c.customer_id
      and i.invoice_date >= date_add(curdate(), interval -3 month)
);