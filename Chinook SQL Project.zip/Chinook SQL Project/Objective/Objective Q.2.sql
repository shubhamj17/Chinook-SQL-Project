-- Q2 Top selling tracks and top artists in USA with most famous genres

select 
t.name as Track_Name,
sum(i.total) as Total_Sales,
ar.name as Artist_Name,
g.name as Genre
from track t
join invoice_line il on t.track_id=il.track_id
join invoice i on i.invoice_id=il.invoice_id
join genre g on t.genre_id=g.genre_id
join album am on t.album_id=am.album_id
join artist ar on am.artist_id=ar.artist_id
where i.billing_country = "USA"
group by t.name,ar.name,g.name
order by Total_Sales desc