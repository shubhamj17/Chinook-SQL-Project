

-- Q.10 Find customers who have purchased tracks from at least 3 different genres

select 
c.Customer_id,
Concat(c.first_name,' ',c.last_name) as Customer_Name,
count(distinct t.genre_id) as Number
from track t
join invoice_line il on t.track_id=il.track_id
join invoice i on i.invoice_id=il.invoice_id
join customer c on c.customer_id=i.customer_id
group by c.customer_id,c.first_name
having count(distinct t.genre_id) >= 3
order by c.customer_id
