
-- Q.6 Identify the top-selling track for each customer

Unable to get single Customer and Track Name as many customer have purchases multiple tracks in same quantity
So, after discussing in the Doubt solver session, it was told to retain the name of the Track that comes first in Alphabatical order

with Top_Selling_Tracks as(
select 
concat(c.first_name,' ',c.last_name) as Customer_Name,
t.name as Track_Name,
sum(i.total) as Total_Sales,
rank() over(partition by concat(c.first_name,' ',c.last_name) order by sum(i.total) desc, t.name asc) as rnk
from customer c
join invoice i on c.customer_id=i.customer_id
join invoice_line il on i.invoice_id=il.invoice_id
join track t on il.track_id=t.track_id
group by concat(c.first_name,' ',c.last_name), t.name
order by Customer_Name 
)

Select Customer_Name,Track_Name
from Top_Selling_Tracks
where rnk = 1 
