
-- Q.3 What is the customer demographic breakdown (age, gender, location) of Chinook's customer base?

-- Since there are no columns for age and gender, I am going with location only as country and adding some more insights to it

with customerranking as (
select 
	i.billing_country as Country,
    count(distinct i.customer_id) as No_of_Customers,
    sum(i.total) as Total_Sales,
    g.name as Genre_Name,
    am.title as Album_title,
    ar.name as Artist_Name,
    rank() over (partition by i.billing_country order by sum(i.total) desc) as rnk
FROM track t
JOIN invoice_line il ON t.track_id = il.track_id
JOIN invoice i ON i.invoice_id = il.invoice_id
JOIN genre g ON t.genre_id = g.genre_id
JOIN album am ON t.album_id = am.album_id
join artist ar on am.artist_id=ar.artist_id
group by i.billing_country,g.name,am.title,ar.name
order by country
)

select Country,No_of_Customers,Genre_Name,Album_title,Artist_Name
from customerranking
where rnk = 1
