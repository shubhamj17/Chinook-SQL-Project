
-- Q4. Calculate the total revenue and number of invoices for each country, state, and city:

select 
billing_country as Country,
billing_state as State,
billing_city as City,
sum(total) as Total_Revenue,
count(invoice_id) as No_of_Invoices
from invoice
group by billing_country,billing_state,billing_city
order by billing_country,billing_state,billing_city