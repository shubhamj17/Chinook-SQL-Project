

-- Q.1 Does any table have missing values or duplicates? If yes how would you handle it ?

SELECT *, COUNT(*) AS count
FROM employee
GROUP BY employee_id,first_name,last_name,title,reports_to,birthdate,hire_date,address,city,state,country,postal_code,phone,fax,email -- List all columns here
HAVING COUNT(*) > 1;

SELECT *, COUNT(*) AS count
FROM track
GROUP BY track_id 
HAVING COUNT(*) > 1;