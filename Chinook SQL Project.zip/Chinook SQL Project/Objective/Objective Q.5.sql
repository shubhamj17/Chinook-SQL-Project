
-- Q.5 Find the top 5 customers by total revenue in each country

-- make list like, country, and then customer name and top 5 customers in each country

with CountryRankings as(
select 
i.billing_country as Country,
concat(c.first_name,' ',c.last_name) as Customer_Name,
sum(i.total) as Total_Revenue,
rank() over(partition by i.billing_country order by sum(i.total) desc) as rnk
from customer c
join invoice i on c.customer_id=i.customer_id
group by concat(c.first_name,' ',c.last_name),i.billing_country
order by country,Total_Revenue desc
)

select Country,Customer_Name,Total_Revenue from CountryRankings where rnk <=5