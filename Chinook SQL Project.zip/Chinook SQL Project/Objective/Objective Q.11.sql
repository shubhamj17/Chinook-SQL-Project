

-- Q.11 Rank genres based on their sales performance in the USA

select g.name as Genre_Name,sum(i.total) as Total_Sales,rank() over(order by sum(i.total) desc) as Genre_Rank
from track t
join invoice_line il on t.track_id=il.track_id
join invoice i on i.invoice_id=il.invoice_id
join genre g on t.genre_id=g.genre_id
where i.billing_country = "USA"
group by g.name